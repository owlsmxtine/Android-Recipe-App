package com.sundram.brandedlaunchscreen.Adapter;

public class ItemListener {

}
